class Plugin(SCMPlugin):

    def __init__(self):
        pass

    def 
