class Plugin():
    def __init__(self):
        print('created plugin')

